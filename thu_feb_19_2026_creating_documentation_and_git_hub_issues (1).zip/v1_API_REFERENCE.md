# EFMS API Reference

## Overview

This document describes the AJAX endpoints used in the Education Financial Management System. All endpoints use POST/GET methods and return JSON responses.

---

## Authentication & Security

### CSRF Protection
All POST requests require a CSRF token in the request header:

```javascript
headers: {
  'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
}