# Education Financial Management System (EFMS)

A comprehensive web-based financial management system designed for educational institutions in Cambodia. The EFMS enables schools to manage budgets, track financial transactions, and maintain inventory records efficiently.

## 🎯 Overview

The Education Financial Management System is a full-featured dashboard application that streamlines financial operations for schools. It provides tools for budget planning, expense tracking, inventory management, and financial reporting with support for both English and Khmer languages.

## ✨ Key Features

### 1. **Budget Management**
- Budget ceiling configuration
- Annual budget planning with Source of Funds (SOF) tracking
- Meeting budget planning and allocation
- Performance indicator setting and tracking
- Budget strategy planning (ផែនការយុទ្ធសាស្រ្តថវិកា)
- Annual operating plan (AOP) management

### 2. **Budget Allocation & Execution**
- Remaining budget tracking from previous years
- Early budget allocation
- Revised budget management
- Receipt and disbursement transaction processing
- Refund management (cash on hand and bank)

### 3. **Inventory Management**
- Stock in/out transaction recording
- Inventory analysis and reporting
- Inventory closing entries
- Excel-based inventory upload

### 4. **Financial Reporting**
- Cash book maintenance
- Financial statement generation
- Report uploads with validation
- Multi-level financial data processing

### 5. **User Management**
- Role-based access control
- Account settings and profile management
- Fiscal year configuration
- School level management
- Secure password change with validation

### 6. **Multi-language Support**
- English and Khmer (ខ្មែរ) language support
- Khmer date picker integration
- Localized number formatting

## 📋 Technical Stack

### Frontend
- **HTML5** - Semantic markup structure
- **Bootstrap 4** - Responsive UI framework
- **jQuery** - DOM manipulation and AJAX
- **XLSX.js** - Excel file processing
- **iziToast** - Toast notifications
- **SweetAlert** - Modal confirmations
- **Select2** - Enhanced select dropdowns
- **Chart.js** - Data visualization
- **FontAwesome 5** - Icon library
- **Feather Icons** - Minimalist icon set
- **Bootstrap Icons** - Icon library

### Key Libraries
- **Perfect Scrollbar** - Custom scrollbar
- **Sidebar Navigation** - Collapsible navigation
- **Timeline JS** - Timeline visualization
- **Pagination JS** - Dynamic pagination
- **Bootstrap Datepicker** - Date selection

## 🚀 Installation

### Prerequisites
- Web server (Apache, Nginx, or similar)
- PHP 7.4 or higher (for backend)
- Node.js 12+ (optional, for build tools)
- Modern web browser

### Setup Instructions

1. **Clone the repository**
   ```bash
   git clone https://github.com/yourusername/education-financial-management.git
   cd education-financial-management