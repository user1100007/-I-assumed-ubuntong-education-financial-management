# Education Financial Management System (EFMS)

## Overview

The **Education Financial Management System (EFMS)** is a comprehensive web-based dashboard designed for managing financial operations of educational institutions, particularly schools in Cambodia. It provides tools for budget planning, allocation, execution, inventory management, and financial reporting with full support for both English and Khmer languages.

**Prepared by:** Department of Finance

---

## Key Features

### 📊 Dashboard
- Central overview and quick access to key financial modules
- Fiscal year selection (currently 2025)
- School information display

### 💼 Budget Plan Preparation
- **Budget Ceiling**: Set spending limits
- **Annual Budget Planning**: Detailed fiscal year planning with SOF (Source of Funds)
- **Meeting Budget Planning**: Meeting-specific budget allocation
- **Performance Indicator and Target**: Track KPIs and targets
- **Budget Strategic Plan (ផែនការយុទ្ធសាស្រ្តថវិកា)**: Strategic financial planning
- **Annual Operating Plan**: Operational budget planning

### 💰 Budget Allocation
- **Remaining Budget**: Manage carry-over funds
- **Old Year Loan**: Track multi-year loans
- **Remaining Budget Last Year**: Previous year carryover
- **Early Budget**: Early fiscal allocations
- **Revised Budget**: Budget adjustments and revisions

### 📥 Budget Execution/Implementation
- **Upload Excel System**: Bulk data import for budget execution
- **Receipt Transaction**: Record income and receipts
- **Disbursement Transaction**: Record expenses and payments
- **Refund Cash On Hand**: Manage refunds
- **Cash Payment at the Bank**: Bank transaction records

### 📦 Material Accounting Registration
- **Upload Inventory**: Bulk inventory import
- **Stock In Transaction**: Record inventory additions
- **Stock Out Transaction**: Record inventory removals
- **Inventory Analysis**: Inventory insights and reporting
- **Inventory Closing Entry**: Period closing procedures

### 📈 Cash Book and Statement
- **Annual Budget Plan Report**: Budget vs. execution analysis
- **Cash Book and Financial Statement**: Complete financial statements

### 🏫 School Management
- **School Information**: View and manage school profile
- **School Statistic Quote**: Demographic and statistical data
- **Feedback System**: User feedback collection
- **About System**: System information and help
- **Website and Document**: External links and resources

---

## Technology Stack

| Component | Technology |
|-----------|-----------|
| **Frontend** | HTML5, Bootstrap 4, jQuery |
| **UI Components** | iziToast, SweetAlert, Select2, Chart.js |
| **Data Processing** | XLSX.js (Excel file handling) |
| **Styling** | Bootstrap 4 CSS, Custom CSS |
| **Localization** | English, Khmer (ខ្មែរ) |
| **Date Handling** | Bootstrap Datepicker, Khmer Datepicker |
| **Icons** | Bootstrap Icons, Fontawesome, Feather Icons |

---

## System Requirements

- Modern web browser (Chrome, Firefox, Safari, Edge)
- JavaScript enabled
- Recommended screen resolution: 1024x768 or higher
- Internet connection for AJAX operations

---

## Sample School Profile

| Field | Value |
|-------|-------|
| **Code** | 01030401017 |
| **School Name** | សាលាបឋមសិក្សា រោគ |
| **School Latin Name** | Primary School : Rauk |
| **Province/City** | ខេត្តបន្ទាយមានជ័យ (Banteay Meanchey) |
| **District/Khan** | ស្រុកភ្នំស្រុក (Phnom Srok) |
| **Commune/Sangkat** | ស្ពានស្រែង (Spean Srang) |
| **Fiscal Year** | 2025 |
| **Prepared by** | Department of Finance |

---

## Getting Started

1. **Access the System**: Open the EFMS dashboard in your web browser
2. **Login**: Enter your credentials
3. **Select Fiscal Year**: Choose the fiscal year from the top menu
4. **Choose Module**: Select from the sidebar menu
5. **Switch Language**: Toggle between English and ខ្មែរ in the top-right corner

---

## Installation & Deployment

See [INSTALLATION.md](./INSTALLATION.md) for detailed setup instructions.

---

## Documentation

- [USER_GUIDE.md](./USER_GUIDE.md) - End-user manual with step-by-step instructions
- [DEVELOPER_GUIDE.md](./DEVELOPER_GUIDE.md) - Technical documentation for developers
- [MODULES.md](./MODULES.md) - Detailed module descriptions
- [API_REFERENCE.md](./API_REFERENCE.md) - AJAX endpoints and integration points

---

## Support

For technical support, feedback, or questions:
- Use the **Feedback** button in the system
- Contact the Department of Finance
- Refer to the **About System** section for resources

---

## License

This project is managed by the Department of Finance.

---

**Last Updated:** 2026-02-18  
**Current Version:** 1.0  
**Fiscal Year:** 2025